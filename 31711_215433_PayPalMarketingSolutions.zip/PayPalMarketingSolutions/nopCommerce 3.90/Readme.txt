1. 'Nop.Plugin.Widgets.PayPalMarketingSolutions' directory contains source code.
2. 'Widgets.PayPalMarketingSolutions' contains binaries. Just drop it into \Plugins directory on your server.
